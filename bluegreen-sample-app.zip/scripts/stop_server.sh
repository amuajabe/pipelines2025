#!/bin/bash
systemctl stop nginx || true
