#!/bin/bash
apt update -y
apt install -y nginx
